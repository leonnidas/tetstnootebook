# Coursera_Capstone_The_Battle_Of_Neighborhoods

Coursera Capstone - Applied Data Science Capstone - The Battle Of Neighborhoods(Part2)

This is a submission of Peer Graded Assignment - Capstone Project - The Battle of Neighborhoods. Please refer and review the respective documents.
