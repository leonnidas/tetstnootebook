# Coursera_Capstone_The_Battle_Of_Neighborhoods

Coursera Capstone - Applied Data Science Capstone - The Battle Of Neighborhoods(Part1)

This is a submission of Peer Graded Assignment - Capstone Project The Battle of Neighborhoods. The solution is for the Introduction/Business Problem and the Data Section. Please refer and review the respective PDF documents Introduction_BusinessProblem and Data_Section attached in this repository.
